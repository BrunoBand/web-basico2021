export default [
    {
        id: 1,
        name: 'Paulo Silva',
        email: 'paulo@mail.com',
        avatarUrl: 'https://cdn.pixabay.com/photo/2014/04/03/10/32/businessman-310819_960_720.png'
    },
    {
        id: 2,
        name: 'Maria Souza',
        email: 'maria@mail.com',
        avatarUrl: 'https://cdn.pixabay.com/photo/2016/04/26/07/57/woman-1353825_960_720.png'
    },
    {
        id: 3,
        name: 'Julio Matos',
        email: 'julio@mail.com',
        avatarUrl: 'https://cdn.pixabay.com/photo/2015/03/04/22/35/head-659651_960_720.png'
    },
    {
        id: 4,
        name: 'Carla Bastos',
        email: 'carla@mail.com',
        avatarUrl: 'https://cdn.pixabay.com/photo/2014/04/03/10/32/user-310807_960_720.png'
    }
]